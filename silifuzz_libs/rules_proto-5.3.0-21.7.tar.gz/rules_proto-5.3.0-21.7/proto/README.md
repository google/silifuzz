Unless explicitly stated otherwise, everything in this folder and all subfolders
is considered to be an implementation detail and may change at any time without
prior notice.

Exceptions from this rule:
  - All symbols exported in `//proto:defs.bzl` and `//proto:repositories.bzl`.