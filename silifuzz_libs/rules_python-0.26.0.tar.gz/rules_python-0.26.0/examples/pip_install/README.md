# pip_install example

This example shows how to use pip to fetch external dependencies from a requirements.txt file,
then use them in BUILD files as dependencies of Bazel targets.
