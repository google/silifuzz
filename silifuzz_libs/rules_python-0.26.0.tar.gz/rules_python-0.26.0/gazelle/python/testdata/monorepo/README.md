# Monorepo

This test case focuses on having multiple configurations tweaked in combination
to simulate a monorepo.
