# Per-file generation

This test case generates one `py_library` per file in subdirectories.
