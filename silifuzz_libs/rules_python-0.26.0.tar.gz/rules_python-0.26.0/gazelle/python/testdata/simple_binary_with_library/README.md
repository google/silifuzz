# Simple binary with library

This test case asserts that a simple `py_binary` is generated as expected
referencing a `py_library`.
