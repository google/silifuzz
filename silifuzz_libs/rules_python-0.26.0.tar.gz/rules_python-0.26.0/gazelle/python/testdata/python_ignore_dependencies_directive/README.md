# python_ignore_dependencies directive

This test case asserts that the target is generated ignoring some of the
dependencies.
