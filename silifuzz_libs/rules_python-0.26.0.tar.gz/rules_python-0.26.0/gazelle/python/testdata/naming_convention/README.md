# Naming convention

This test case asserts that py\_{library,binary,test} targets are generated
correctly based on the directives that control their naming conventions.
