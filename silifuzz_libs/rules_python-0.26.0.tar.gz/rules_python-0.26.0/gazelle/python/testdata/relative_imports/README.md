# Relative imports

This test case asserts that the generated targets handle relative imports in
Python correctly.
