# File name matches import statement

This test case asserts that a file with an import statement that matches its own
name does the right thing of resolving the third-party package.
