# Disable import statements validation

This test case asserts that the module's validation step is not performed.
