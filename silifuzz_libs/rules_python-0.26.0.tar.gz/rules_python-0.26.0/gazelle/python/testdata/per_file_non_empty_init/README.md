# Per-file generation

This test case generates one `py_library` per file, including `__init__.py`.
