// Copyright 2023 The Centipede Authors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "./centipede/remote_file.h"

#include <filesystem>  // NOLINT
#include <fstream>
#include <string>
#include <string_view>
#include <vector>

#include "gmock/gmock.h"
#include "gtest/gtest.h"
#include "absl/log/check.h"
#include "./centipede/logging.h"
#include "./centipede/test_util.h"

namespace centipede {
namespace {

namespace fs = std::filesystem;

using ::testing::IsEmpty;
using ::testing::UnorderedElementsAre;

void CreateFileOrDie(std::string_view path, std::string_view contents = "") {
  std::ofstream f{std::string(path)};
  CHECK(f.good()) << VV(path);
  f << contents;
  CHECK(f.good()) << VV(path);
}

TEST(RemoteFile, GetSize) {
  const fs::path temp_dir{GetTestTempDir(test_info_->name())};
  const std::string file_path = temp_dir / "file_01";
  {
    const std::string file_contents1 = "abcd1234";
    CreateFileOrDie(file_path, file_contents1);
    EXPECT_EQ(RemoteFileGetSize(file_path), file_contents1.size());
  }
  {
    const std::string file_contents2 = "efg567";
    RemoteFileSetContents(file_path, file_contents2);
    EXPECT_EQ(RemoteFileGetSize(file_path), file_contents2.size());
  }
}

TEST(RemoteListFilesRecursively, ListsFilesInRecursiveDirectories) {
  const fs::path temp_dir = GetTestTempDir(test_info_->name());

  const std::string file1_path = temp_dir / "file_01";
  CreateFileOrDie(file1_path);
  const std::string file2_path = temp_dir / "file_02";
  CreateFileOrDie(file2_path);

  const fs::path dir1_path = temp_dir / "dir_01";
  fs::create_directories(dir1_path);
  const std::string file3_path = dir1_path / "file_03";
  CreateFileOrDie(file3_path);

  const std::vector<std::string> files =
      RemoteListFilesRecursively(temp_dir.string());
  EXPECT_THAT(files, UnorderedElementsAre(file1_path, file2_path, file3_path));
}

TEST(RemoteListFilesRecursively, ReturnsAnEmptyResultWhenNoFilesAreFound) {
  const fs::path temp_dir = GetTestTempDir(test_info_->name());
  EXPECT_THAT(RemoteListFilesRecursively(temp_dir.string()), IsEmpty());
}

TEST(RemoteFilesListRecursively, ReturnsASingleFileWhenListingAFile) {
  const fs::path temp_dir = GetTestTempDir(test_info_->name());

  const std::string file1_path = temp_dir / "file_01";
  CreateFileOrDie(file1_path);

  const std::vector<std::string> files =
      RemoteListFilesRecursively(temp_dir.string());
  EXPECT_THAT(files, UnorderedElementsAre(file1_path));
}

TEST(RemoteFilesListRecursively, ReturnsAnEmptyVectorWhenPathDoesNotExist) {
  const std::vector<std::string> files =
      RemoteListFilesRecursively("/this/file/path/does/not/exist");
  EXPECT_THAT(files, IsEmpty());
}

}  // namespace
}  // namespace centipede
