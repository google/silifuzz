The files under this directory are generated! Do not edit!

To generate these files, use the grammar files at
https://github.com/antlr/grammars-v4/tree/4f16c947878c303da520e21ac75272eb8443fc2f/antlr/antlr4.

We make the following modification:

1.  Merged LexerAdaptor.h/cpp and LexBasic.g4 with ANTLRv4Lexer.g4.
2.  Fix grammar to work with C++ following
    https://github.com/antlr/grammars-v4/issues/2239.
