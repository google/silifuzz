
int some_function() {
  return 0;
}
